package com.robotemplates.webviewapp;

import android.app.Application;
import android.content.Context;

import com.google.android.gms.ads.MobileAds;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.onesignal.OneSignal;
import com.robotemplates.webviewapp.ads.AdMobUtility;
import com.robotemplates.webviewapp.fcm.OneSignalNotificationOpenedHandler;
import com.robotemplates.webviewapp.utility.Preferences;

import org.alfonz.utility.Logcat;

public class WebViewAppApplication extends Application {
	private static WebViewAppApplication sInstance;

	public WebViewAppApplication() {
		sInstance = this;
	}

	public static Context getContext() {
		return sInstance;
	}

	@Override
	public void onCreate() {
		super.onCreate();

		// init logcat
		Logcat.init(WebViewAppConfig.LOGS, "WEBVIEWAPP");

		// init analytics
		FirebaseAnalytics.getInstance(this).setAnalyticsCollectionEnabled(!WebViewAppConfig.DEV_ENVIRONMENT);

		// init AdMob
		MobileAds.initialize(this);
		MobileAds.setRequestConfiguration(AdMobUtility.createRequestConfiguration());

		// init OneSignal
		initOneSignal(getString(R.string.onesignal_app_id));
	}

	public String getPurchaseCode() {
		return WebViewAppConfig.PURCHASE_CODE;
	}

	private void initOneSignal(String oneSignalAppId) {
		if (!oneSignalAppId.equals("")) {
			OneSignal.initWithContext(this);
			OneSignal.setAppId(oneSignalAppId);
			OneSignal.setNotificationOpenedHandler(new OneSignalNotificationOpenedHandler());
			OneSignal.addSubscriptionObserver(stateChanges -> {
				if (stateChanges.getTo().isSubscribed()) {
					String userId = stateChanges.getTo().getUserId();
					saveOneSignalUserId(userId);
				}
			});
			saveOneSignalUserId(OneSignal.getDeviceState().getUserId());
		}
	}

	private void saveOneSignalUserId(String userId) {
		if (userId != null) {
			Logcat.d("userId = " + userId);
			Preferences preferences = new Preferences();
			preferences.setOneSignalUserId(userId);
		}
	}
}
