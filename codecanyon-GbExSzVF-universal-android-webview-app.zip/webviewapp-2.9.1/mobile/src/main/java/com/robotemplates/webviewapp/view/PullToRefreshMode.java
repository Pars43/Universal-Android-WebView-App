package com.robotemplates.webviewapp.view;

public enum PullToRefreshMode {ENABLED, PROGRESS, DISABLED}
